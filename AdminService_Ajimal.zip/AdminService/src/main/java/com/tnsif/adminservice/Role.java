package com.tnsif.adminservice;

public enum Role {
	Super_Admin,
	Manager,
	Staff
}
